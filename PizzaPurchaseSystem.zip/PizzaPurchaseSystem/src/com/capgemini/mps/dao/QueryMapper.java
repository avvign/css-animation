package com.capgemini.mps.dao;

public interface QueryMapper {
	public static final String RETRIEVE_ALL_PizzaS = "SELECT * FROM Pizzas";
	public static final String DELETE_Pizza = "DELETE FROM Pizzas WHERE Pizzaid=?";
	public static final String QUERY_Pizza_RANGE = "SELECT * from Pizzas where price BETWEEN ? AND ?";
	public static final String CHECK_VALID_Pizza_ID = "SELECT * FROM Pizzas WHERE Pizzaid=?";
	public static final String ADD_PURCHASE_DETAILS="INSERT INTO pizzadetails VALUES(purchaseid_sequence.NEXTVAL,?,?,?,SYSDATE,?)";
	public static final String RETRIEVE_Pizza="select * from Pizzas where Pizzaid=?";
	public static final String UPDATE_Pizza_QUANTITY="UPDATE Pizzas set quantity=quantity-? where PizzaId=?";
	public static final String RETRIEVE_PURCHASEID="SELECT purchaseid_sequence.CURRVAL from dual";

}
