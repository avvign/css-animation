package com.capgemini.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.mps.bean.Pizza;
import com.capgemini.mps.exception.PizzaPurchaseException;
import com.capgemini.mps.util.DBConnection;

public class PizzaDaoImpl implements IPizzaDAO {
	

	@Override
	public String deletePizza(Integer PizzaId) throws PizzaPurchaseException {
		try (
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.DELETE_Pizza);
				) {
			preparedStatement.setInt(1, PizzaId);
			int n = preparedStatement.executeUpdate();
			if(n>0) {
				return "SUCCESS";
			} else {
				return "FAIL";
			}
		} catch(SQLException e){
			throw new PizzaPurchaseException("Technical error. Refer to log");
		}
	}

	@Override
	public List<Pizza> getPizzaDetails() throws PizzaPurchaseException {
		int PizzaCount = 0;
		try(
				Connection connection = DBConnection.getConnection();
				Statement statement = connection.createStatement();
				) {
			ResultSet resultSet = statement.executeQuery(QueryMapper.RETRIEVE_ALL_PizzaS);
			List<Pizza> PizzaList = new ArrayList<Pizza>();
			while (resultSet.next()) {
				PizzaCount++;
				Pizza Pizza = new Pizza();
				populatePizza(Pizza,resultSet);
				PizzaList.add(Pizza);
				System.out.println(Pizza);
			}if (PizzaCount>0) {
				return PizzaList;
			}else{
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void populatePizza(Pizza Pizza, ResultSet resultSet) throws SQLException {
		Pizza.setPizzaid(resultSet.getInt("Pizzaid"));
		Pizza.setName(resultSet.getString("name"));
		Pizza.setPrice(resultSet.getDouble("price"));
		Pizza.setQuantity(resultSet.getInt("quantity"));
	}

	@Override
	public List<Pizza> getPizzasPriceRange(Double lowPrice, Double highPrice)
	throws PizzaPurchaseException{
	int PizzaCount=0;
	try(
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.QUERY_Pizza_RANGE);
	){
		preparedStatement.setDouble(1, lowPrice);
		preparedStatement.setDouble(2, highPrice);
		ResultSet resultSet = preparedStatement.executeQuery();
		List<Pizza> PizzaList= new ArrayList<>();
			while(resultSet.next()){
			PizzaCount++;
			Pizza Pizza = new Pizza();
			populatePizza(Pizza, resultSet);
			PizzaList.add(Pizza);
		}
		if(PizzaCount!=0){
			return PizzaList;
		}else {
			return null;
		}
	}
		 catch (SQLException e){
		throw new PizzaPurchaseException("Technical error. Contact logs.");
	}
	}

	@Override
	public Boolean isValidPizzaId(Integer PizzaId) throws PizzaPurchaseException {
		try(
			Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.CHECK_VALID_Pizza_ID);
				){
			preparedStatement.setInt(1, PizzaId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				return true;
			}
			return false;
		}catch(SQLException e) {
			//log to file
			throw new PizzaPurchaseException("Technical Error. Contact Log");
		}
	}

	@Override
	public Pizza getPizzaDetails(Integer PizzaId) throws PizzaPurchaseException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.RETRIEVE_Pizza);
				){
			
			preparedStatement.setInt(1, PizzaId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				Pizza Pizza = new Pizza();
				populatePizza(Pizza,resultSet);
				return Pizza;
			}
			return null;
			
		}catch(SQLException e){
			//Log to file
			throw new PizzaPurchaseException("Technical Error. Contact logs.");
		}
	}

	@Override
	public Integer addPizza(Pizza Pizza) throws PizzaPurchaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer updatePizzaQuantity(Integer PizzaId, Integer quantity) throws PizzaPurchaseException {
		try (
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_Pizza_QUANTITY);
				) {
			preparedStatement.setInt(1, quantity);
			preparedStatement.setInt(2, PizzaId);
			int n = preparedStatement.executeUpdate();
			return n;
		} catch(SQLException e){
			//log file
			throw new PizzaPurchaseException("Technical error. Refer to log");
		}
		
	}
}


