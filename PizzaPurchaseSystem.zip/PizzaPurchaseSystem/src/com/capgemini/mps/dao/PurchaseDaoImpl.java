package com.capgemini.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.mps.exception.PizzaPurchaseException;
import com.capgemini.mps.util.DBConnection;

public class PurchaseDaoImpl implements IPurchaseDAO {

	@Override
	public Integer addPurchaseDetails(String name, String emailId,
			Long phoneNumber, Integer PizzaId) throws PizzaPurchaseException{
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.ADD_PURCHASE_DETAILS);
				Statement statement = connection.createStatement();
				){
			preparedStatement.setString(1, name);
			preparedStatement.setString(2, emailId);
			preparedStatement.setLong(3, phoneNumber);
			preparedStatement.setInt(4, PizzaId);
			int n = preparedStatement.executeUpdate();
			
			if(n>0) {
				
				new PizzaDaoImpl().updatePizzaQuantity(PizzaId, 1);
				ResultSet resultSet = statement.executeQuery(QueryMapper.RETRIEVE_PURCHASEID);
				if(resultSet.next()){
				Integer purchaseId = resultSet.getInt(1);
				return purchaseId;
			}}
			return 0;
		}catch(SQLException e){
		//log to file
			throw new PizzaPurchaseException("Technical Error. Refer logs");
	}
	
}
}