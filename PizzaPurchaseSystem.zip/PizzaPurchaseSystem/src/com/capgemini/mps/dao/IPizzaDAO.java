package com.capgemini.mps.dao;

import java.util.List;

import com.capgemini.mps.bean.Pizza;
import com.capgemini.mps.exception.PizzaPurchaseException;

public interface IPizzaDAO {
	public String deletePizza(Integer PizzaId) throws PizzaPurchaseException;
	public List<Pizza> getPizzaDetails() throws PizzaPurchaseException;
	public List<Pizza> getPizzasPriceRange(Double lowPrice, Double highPrice) throws PizzaPurchaseException;
	public Boolean isValidPizzaId(Integer PizzaId) throws PizzaPurchaseException;
	public Pizza getPizzaDetails(Integer PizzaId) throws PizzaPurchaseException;
	public Integer addPizza(Pizza Pizza) throws PizzaPurchaseException;
	public Integer updatePizzaQuantity(Integer PizzaId,Integer quantity) throws PizzaPurchaseException;
	
}
