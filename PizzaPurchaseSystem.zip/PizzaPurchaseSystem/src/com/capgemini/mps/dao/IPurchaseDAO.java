package com.capgemini.mps.dao;

import com.capgemini.mps.exception.PizzaPurchaseException;

public interface IPurchaseDAO {
	public Integer addPurchaseDetails(String name, String emailId, Long phoneNumber, Integer PizzaId) throws PizzaPurchaseException;
}
