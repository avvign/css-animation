package com.capgemini.mps.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.mps.bean.Pizza;
import com.capgemini.mps.exception.PizzaPurchaseException;
import com.capgemini.mps.service.CustomerValidator;
import com.capgemini.mps.service.IpizzaService;
import com.capgemini.mps.service.IpurchaseService;
import com.capgemini.mps.service.PizzaServiceImpl;
import com.capgemini.mps.service.PurchaseServiceImpl;

public class PPSMain {
	
	private static Scanner scanner = new Scanner(System.in);
	private static IpizzaService PizzaService = new PizzaServiceImpl();
	private static IpurchaseService purchaseService=new PurchaseServiceImpl();
	
	private static Logger myUILogger = Logger.getLogger(PPSMain.class);
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resource/log4j.properties");
	while (true) {

		// show menu
		System.out.println();
		System.out.println();
		System.out.println("  PIZZA PURCHASE SYSTEM  ");
		System.out.println("_______________________________\n");

		System.out.println("1. Purchase Pizza");
		System.out.println("2. Search for pizza based on price range");
		System.out.println("3. Retrive All Pizzas");
		System.out.println("4. Delete Pizza");
		System.out.println("5. Add Pizza");
		System.out.println("6. Exit");
		System.out.println("________________________________");
		System.out.println("Select an option: ");
		// accept option

		try {
			int option = scanner.nextInt();

			switch (option) {
			
			case 1:
				System.out.println("Enter customer name (begin with uppercase and name cannot exceed 20 charachers): ");
				scanner.nextLine();//KBD Buffer
				String name = scanner.nextLine();
				System.out.println("Enter EmailId: ");
				String emailId = scanner.nextLine();
				//scanner.nextLine();//clear KBD buffer
				System.out.println("Enter 10-Digit phone number");
				Long phoneNumber = scanner.nextLong();
				scanner.nextLine();
				CustomerValidator validator = new CustomerValidator();
				if(validator.isValidCustomerName(name)) {
					if(validator.isValidEmail(emailId)) {
						if(validator.isValidPhoneNumber(phoneNumber)){
							/*PurchaseDetails purchaseDetails = new PurchaseDetails();
							purchaseDetails.setCustomerName(name);
							purchaseDetails.setEmailId(emailId);
							purchaseDetails.setPhoneNumber(phoneNumber);*/
							System.out.println("Enter Pizza ID: \nAvailable Pizzas:\n1001: Chicken Pizza --- Rs. 100\n1002: Paneer Pizza --- Rs. 150\n1003: Tandoori Pizza --- Rs. 200\n1004: Mutton Pizza --- Rs. 250");
							Integer mid = scanner.nextInt();
							try {
								if(PizzaService.isValidPizzaId(mid)){
								//	purchaseDetails.setPizzaId(mid);
									Integer purchaseId= addPurchaseDetails(name,emailId,phoneNumber,mid);
									System.out.println("Order successfully placed with Purchase ID: PZA"+purchaseId);
								} else {
									System.out.println("Enter a valid Pizza ID");
									
								}
							} catch (PizzaPurchaseException e) {
								System.out.println(e.getMessage());
							}
						}else {
							System.out.println("Enter a valid phone number");
						}
					}
				}
				break;
			
			case 2:
				System.out.println("Enter lower limit and upper limit price range...");
				double lowPrice = scanner.nextDouble();
				double highPrice = scanner.nextDouble();
				List<Pizza> PizzaList = getPizzaPriceRange(lowPrice,highPrice);
				showPizzas(PizzaList);
				break;
				
			case 3:
				List<Pizza> pizzaList2 = getPizzaDetails();//List<Mobile> mobileList2 = getMobileDetails();
				showPizzas(pizzaList2);
				break;
				
			case 4:
				System.out.println("Enter Pizza ID to be deleted");
				int PizzaId = scanner.nextInt();
				String status = deletePizza(PizzaId);
				System.out.println(status);
				break;
				
			case 5:
				break;

			case 6:
				System.out.print("Exit Trust Application");
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid option[1-6]");
			}// end of switch
		}

		catch (InputMismatchException e) {
			myUILogger.warn("Enter only integer values[1-6]");
			scanner.nextLine();
			System.err.println("Please enter a numeric value and try again");
		}

		}// end of while
	}// end of main
	private static Integer addPurchaseDetails(String name, String emailId,
			Long phoneNumber, Integer mid) {
		try {
			Integer purchaseId = purchaseService.addPurchaseDetails(name, emailId, phoneNumber,mid);
			return purchaseId;
		}catch(PizzaPurchaseException e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	private static String deletePizza(int PizzaId) {
		try {
			return PizzaService.deletePizza(PizzaId);
		} catch (PizzaPurchaseException e) {
			myUILogger.error(e.getMessage());
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return null;
	}
	private static List<Pizza> getPizzaPriceRange(double lowPrice,
			double highPrice) {
		try {
			return PizzaService.getPizzasPriceRange(lowPrice, highPrice);
		} catch (PizzaPurchaseException e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	private static void showPizzas(List<Pizza> pizzaList2) {
		Iterator<Pizza> iterator = pizzaList2.iterator();   //Iterator<Mobile> iterator = mobileList2.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
	private static List<Pizza> getPizzaDetails() {
	
			try {
				List<Pizza> PizzaList2= PizzaService.getPizzaDetails();
				return PizzaList2;
			} catch (PizzaPurchaseException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
	
		return null;
	}
}//end of class