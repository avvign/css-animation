package com.capgemini.mps.service;

import java.util.List;

import com.capgemini.mps.bean.Pizza;
import com.capgemini.mps.exception.PizzaPurchaseException;

public interface IpizzaService {

	public String deletePizza(Integer PizzaId) throws PizzaPurchaseException;
	public List<Pizza> getPizzaDetails() throws PizzaPurchaseException;
	public List<Pizza> getPizzasPriceRange(Double lowPrice, Double highPrice) throws PizzaPurchaseException;
	public Boolean isValidPizzaId(Integer PizzaId) throws PizzaPurchaseException;

}
