package com.capgemini.mps.service;

import com.capgemini.mps.bean.Pizza;
import com.capgemini.mps.dao.IPurchaseDAO;
import com.capgemini.mps.dao.PizzaDaoImpl;
import com.capgemini.mps.dao.PurchaseDaoImpl;
import com.capgemini.mps.exception.PizzaPurchaseException;

public class PurchaseServiceImpl implements IpurchaseService {
	private IPurchaseDAO purchaseDAO = new PurchaseDaoImpl();

	@Override
	public Integer addPurchaseDetails(String name, String emailId, Long phoneNumber, Integer PizzaId) throws PizzaPurchaseException{
		try{
		Pizza Pizza = new PizzaDaoImpl().getPizzaDetails(PizzaId);
		if(Pizza.getQuantity()>0){
		Integer purchaseId = purchaseDAO.addPurchaseDetails(name, emailId, phoneNumber, PizzaId);
		return purchaseId;
	} else {
		throw new PizzaPurchaseException("No stock");
	}
}catch(PizzaPurchaseException e){
	//log to file
	throw new PizzaPurchaseException("Technical error. Refer to logs");
	
		}
	}
}
