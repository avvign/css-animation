package com.capgemini.mps.service;

import java.util.List;

import com.capgemini.mps.bean.Pizza;
import com.capgemini.mps.dao.IPizzaDAO;
import com.capgemini.mps.dao.PizzaDaoImpl;
import com.capgemini.mps.exception.PizzaPurchaseException;

public class PizzaServiceImpl implements IpizzaService {
	private IPizzaDAO PizzaDAO = new PizzaDaoImpl();

	@Override
	public String deletePizza(Integer PizzaId) throws PizzaPurchaseException {
		return PizzaDAO.deletePizza(PizzaId);
	}

	@Override
	public List<Pizza> getPizzaDetails() throws PizzaPurchaseException {
		List<Pizza> PizzaList = PizzaDAO.getPizzaDetails();
		return PizzaList;
	}

	@Override
	public List<Pizza> getPizzasPriceRange(Double lowPrice, Double highPrice)
			throws PizzaPurchaseException {
		List<Pizza> PizzaList = PizzaDAO.getPizzasPriceRange(lowPrice, highPrice);
		return PizzaList;
	}

	@Override
	public Boolean isValidPizzaId(Integer PizzaId) throws PizzaPurchaseException {
		return PizzaDAO.isValidPizzaId(PizzaId);
	}

}
