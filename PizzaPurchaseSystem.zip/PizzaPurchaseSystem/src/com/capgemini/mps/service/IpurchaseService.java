package com.capgemini.mps.service;

import com.capgemini.mps.exception.PizzaPurchaseException;

public interface IpurchaseService {
	public Integer addPurchaseDetails(String name, String emailId, Long phoneNumber, Integer PizzaId) throws PizzaPurchaseException;

}
