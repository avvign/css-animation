package com.cg.pizza.service;

import com.cg.pizza.bean.Customer;
import com.cg.pizza.bean.PizzaOrder;
import com.cg.pizza.exception.PizzaException;

public interface IPizzaOrderService {

	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException;
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
	
}
