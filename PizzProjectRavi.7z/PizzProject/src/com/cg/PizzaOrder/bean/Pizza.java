package com.cg.PizzaOrder.bean;

public class Pizza {
	
	private String p_nmae;
	private Double p_price;
	private Integer quantity;
	
	public Pizza() {
		super();
	}

	public Pizza(String p_nmae, Double p_price, Integer quantity) {
		super();
		this.p_nmae = p_nmae;
		this.p_price = p_price;
		this.quantity = quantity;
	}

	public String getP_nmae() {
		return p_nmae;
	}

	public void setP_nmae(String p_nmae) {
		this.p_nmae = p_nmae;
	}

	public Double getP_price() {
		return p_price;
	}

	public void setP_price(Double p_price) {
		this.p_price = p_price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Pizz Nmae=" + p_nmae+"   "+ "p_price=" + p_price+"   " 
				+ " quantity=" + quantity ;
	}
	
	

}
