package com.cg.PizzaOrder.bean;

public class PizzaOrder {
	private Integer orderId;
	private Integer custId;
	private Double totalAmount;
	public PizzaOrder() {
		super();
	}
	public PizzaOrder(Integer orderId, Integer custId, Double totalAmount) {
		super();
		this.orderId = orderId;
		this.custId = custId;
		this.totalAmount = totalAmount;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	@Override
	public String toString() {
		return "PizzaOrderData [orderId=" + orderId + ", custId=" + custId
				+ ", totalAmount=" + totalAmount + "]";
	}
	
}
