package com.cg.PizzaOrder.ui;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.PizzaOrder.bean.Pizza;
import com.cg.PizzaOrder.bean.PizzaOrder;
import com.cg.PizzaOrder.exception.PizzaException;
import com.cg.PizzaOrder.service.IPizzaOrderService;
import com.cg.PizzaOrder.service.PizzaOrderService;



public class Client {
public static void main(String[] args) throws PizzaException {
	
	IPizzaOrderService service;
	{
		service = new PizzaOrderService();
	}
	double basePizzaPrice = 0;
	double pizzaToppingsPrice=0;
	double totalPrice=0;
	LocalDate date=null;
int orderId=0;
Scanner sc = new Scanner(System.in);
//sc.useDelimiter("\n");

String choice;
String ans;
do {
	System.out.println("1. Show pizza's");
	System.out.println("2. Place Order");
	System.out.println("3. Display Order");
	System.out.println("4. Exit");
	
	System.out.println(" Enter your CHoice");
	choice=sc.nextLine();
	switch (choice) {
	case "1":
		System.out.println("Available Items: ");
		List<Pizza> pizzaDetails=service.getPizzaDetails();
		Iterator<Pizza> iterator= pizzaDetails.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
		
			break; 

	case "2": 			
		System.out.println("Enter the mobile No. of the customer");
		Long phone=sc.nextLong();
		System.out.println("Enter the name of the customer");
		String custName = sc.next();
		System.out.println("Enter the address of the customer");
		String address=sc.next();
		System.out.println("Select the option of pizza you want to have:"+"\n"+
				"1.Margherita"+"\n"+
				"2.Crudo"+"\n"+
				"3.Romana"+"\n"+
				"4.Montanara"+"\n"+
				"5.Americana");

System.out.println("Eneter your choice: ");
Integer pizza = sc.nextInt();  
switch(pizza){
			case 1:
				basePizzaPrice=300.00;
				System.out.println("u selected me"+basePizzaPrice);
				break;
			case 2:
				basePizzaPrice = 400.00;
				break;
			case 3:
				basePizzaPrice=350.00;
				break;
			case 4:
				basePizzaPrice = 550.00;
				break;
			case 5:
				basePizzaPrice =750.00;
				break;
			default:
				System.out.println("Enter valid option[1-5]");
			}
		System.out.println("Enter the Pizza Topping preffered");
		System.out.println("1.Capsicum");
		System.out.println("2.MushRoom");
		System.out.println("3.Jalapeno");
		System.out.println("4.Paneer");
		Integer topping =sc.nextInt();
		switch (topping) {
		case 1:
			pizzaToppingsPrice=30;
			break;
		case 2:
			pizzaToppingsPrice=50;
			break;
		case 3:
			pizzaToppingsPrice=70;
			break;
	
		case 4:
			pizzaToppingsPrice=85;
			break;
			default:
				System.out.println("Preffered Pizza Toppings are Invalid");
		}
		totalPrice=basePizzaPrice +pizzaToppingsPrice;
		
		orderId=service.placeOrder(custName,phone , address, totalPrice);
		if(orderId !=0) {
			System.out.println("Pizza Order Succesfully placed with Order Id: " +orderId);
		}
		break;
	case "3":
		
	System.out.println("Enter your orderId");
	Integer oId=Integer.parseInt(sc.nextLine());
	if(service.isValidOrderId(oId))
	{
		PizzaOrder pizzaOrder =service.getOrderDetails(oId);
		System.out.println("Customer ID: "+pizzaOrder.getCustId()+"\n"+
				"Order id: "+pizzaOrder.getOrderId()+"\n"+
				"Total Price: "+pizzaOrder.getTotalAmount()); 
	
	}
	break;
	case "4":
		System.exit(0);
		break;
		default:
			System.out.println("Invalid Choice");
	}
	System.out.println("Do you wish to continue? yes/no");
	ans=sc.nextLine();
}
while(ans.equalsIgnoreCase("yes") || ans.equalsIgnoreCase("y"));
sc.close();
	
	
		}
	}


