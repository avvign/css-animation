package com.cg.PizzaOrder.service;

import java.util.List;
import java.util.Scanner;

import com.cg.PizzaOrder.bean.Customer;
import com.cg.PizzaOrder.bean.Pizza;
import com.cg.PizzaOrder.bean.PizzaOrder;
import com.cg.PizzaOrder.dao.IPizzaOrderDAO;
import com.cg.PizzaOrder.dao.PizzaOrderDAO;
import com.cg.PizzaOrder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {

	private IPizzaOrderDAO serviceDAO; 
	Scanner sc =new Scanner(System.in);
	public PizzaOrderService() {
	serviceDAO =new PizzaOrderDAO();
	}
	





	
	
	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
		
		PizzaOrder pizza=serviceDAO.getOrderDetails(orderId);
		return pizza;
	}

	@Override
	public List<Pizza> getPizzaDetails() throws PizzaException {
		List<Pizza> pizzaDetails=  serviceDAO.getPizzaDetails();
		return pizzaDetails;
	}

	@Override
	public Integer placeOrder(String cname, Long MobileNo, String address,
			Double total_price) throws PizzaException {
		Integer n = serviceDAO.placeOrder(cname, MobileNo, address, total_price);
		return n;
	}

	@Override
	public boolean isValidOrderId(Integer oId) throws PizzaException {
		
		return serviceDAO.isValidOrderId(oId);
	}


	
		
	}

