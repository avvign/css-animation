package com.cg.PizzaOrder.service;

import java.util.List;

import com.cg.PizzaOrder.bean.Customer;
import com.cg.PizzaOrder.bean.Pizza;
import com.cg.PizzaOrder.bean.PizzaOrder;
import com.cg.PizzaOrder.exception.PizzaException;

public interface IPizzaOrderService {


	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
	public List<Pizza> getPizzaDetails() throws PizzaException;
	public Integer placeOrder(String cname,Long phone,String address,Double total_price) throws PizzaException;
	public boolean isValidOrderId(Integer oId)throws PizzaException;

	
}
