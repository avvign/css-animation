package com.cg.PizzaOrder.exception;

public class PizzaException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String messege;

	public PizzaException() {
		super();
	}

	public PizzaException(String messege) {
		super();
		this.messege = messege;
	}

	public String getMessege() {
		return messege;
	}

	public void setMessege(String messege) {
		this.messege = messege;
	}

	@Override
	public String toString() {
		return "PizzaException [messege=" + messege + "]";
	}
	
}