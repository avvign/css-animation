package com.cg.PizzaOrder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;


import com.capgemini.mps.util.DBConnection;
import com.cg.PizzaOrder.bean.Customer;
import com.cg.PizzaOrder.bean.Pizza;
import com.cg.PizzaOrder.bean.PizzaOrder;
import com.cg.PizzaOrder.exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO {
	
	Random random =new Random();
	int orderId;
	int customerId;
	Map<Integer,PizzaOrder> pizzaEntry;
	Map<Integer,Customer> customerEntry;
	List<Customer> customerList;
	List<PizzaOrder> pizzaList;
	{
		pizzaEntry = new HashMap<Integer, PizzaOrder>();
		customerEntry=new HashMap<Integer,Customer>();
		customerList=new ArrayList<Customer>();
		pizzaList=new ArrayList<PizzaOrder>();
						
	}
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		try {
		customerId = random.nextInt(50000);
		customer.setCustomerId(customerId);

		orderId=random.nextInt(5000);
		pizza.setCustId(customerId);
		pizza.setOrderId(orderId);
		customerEntry.put(new Integer(customerId), customer);
		pizzaEntry.put(new Integer(orderId), pizza);
		
		customerList.add(customer);
		pizzaList.add(pizza);
		return orderId;
		
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		return 0;
	}




	@Override
	public List<Pizza> getPizzaDetails() throws PizzaException {
		int pizzaCount = 0;
		
		try(Connection connection = DBConnection.getConnection();
				Statement statement = connection.createStatement();
				){
			ResultSet resultSet = statement.executeQuery(QueryMapper.RETRIEVE_PIZZA);
			List<Pizza> pizzaList = new ArrayList<>();
			while(resultSet.next()){
				
				pizzaCount++;
				Pizza pizza = new Pizza();
				populateMobile(pizza,resultSet);
				pizzaList.add(pizza);
				
			}
			if(pizzaCount!=0){
				
				return pizzaList;
			}else{
				return null;
			}
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		
		return null;
	}

	private void populateMobile(Pizza pizza, ResultSet resultSet) throws SQLException {
		
		pizza.setP_nmae(resultSet.getString("p_nmae"));
		pizza.setP_price(resultSet.getDouble("p_price"));
		pizza.setQuantity(resultSet.getInt("quantity"));
		
	}
	@Override
	public Integer placeOrder(String cname, Long MobileNo, String address,
			Double total_price) throws PizzaException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.ADD_CUSTOMER_DETAILS);
				PreparedStatement preparedStatement1 = connection.prepareStatement(QueryMapper.ADD_ORDER_DETAILS);
				PreparedStatement preparedStatement2 = connection.prepareStatement(QueryMapper.CHECK_PIZZA_ORDERID);
				Statement statement= connection.createStatement();
				Statement statement1= connection.createStatement();
				){
			preparedStatement.setString(1, cname);
			preparedStatement.setLong(2, MobileNo);
			preparedStatement.setString(3, address);
			preparedStatement1.setDouble(1,total_price);
			int n  = preparedStatement.executeUpdate();
			if(n>0){
				int n2 = preparedStatement1.executeUpdate();
				if(n2>0){
					ResultSet resultSet = statement.executeQuery(QueryMapper.Customer_id);
					if(resultSet.next()){
						int i = resultSet.getInt(1);
						if(i>0){
							preparedStatement2.setInt(1, i);
							ResultSet resultSet1 = preparedStatement2.executeQuery();
							if(resultSet1.next()){
								int oid = resultSet1.getInt(1);
								return oid;
							}
						}
	
					}
				}
			}
			else{
				return 0;
			}
		}catch(SQLException e){
			
			throw new PizzaException("technocal issue");
		}
		return null;
	}
	
	@Override
	public boolean isValidOrderId(Integer oId) throws PizzaException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.CHECK_VALID_ID);
				){
			preparedStatement.setInt(1,oId );
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				return true;
			} 
			return false;
		}catch(SQLException e){
			throw new PizzaException("technocal issue");
		}

	}


	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.RETRIEVE_ORDER_DETAILS);
				
				
		){
			preparedStatement.setInt(1, orderId);
			
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()){
				PizzaOrder order=new PizzaOrder();
				populateOrder(order,resultSet);
				
				return order;
				
			}else{
				return null;
			}	
			
			
						
		}catch(SQLException e){
			
			throw new PizzaException("Technical error refer log");
		}
	
}




	private void populateOrder(PizzaOrder order, ResultSet resultSet) throws SQLException {
		order.setOrderId(resultSet.getInt(1));
		order.setCustId(resultSet.getInt(2));
		order.setTotalAmount(resultSet.getDouble(3));
		
	}
}


