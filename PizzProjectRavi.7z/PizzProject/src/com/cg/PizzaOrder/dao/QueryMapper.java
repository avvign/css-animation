package com.cg.PizzaOrder.dao;

public interface QueryMapper {
	
	public static final String RETRIEVE_ORDER_DETAILS="SELECT * FROM orderdetails where orderid=?";
	public static final String DELETE_PIZZA="DELETE FROM MOBILES WHERE mobileid =?";
	public static final String Customer_id = "SELECT sequence_cid.CURRVAL from dual";
	public static final String ADD_CUSTOMER_DETAILS = "INSERT INTO customer2 values(sequence_cid.NEXTVAL,?,?,?)";
	public static final String RETRIEVE_PIZZA = "SELECT * FROM pizza";
	public static final String CHECK_PIZZA_ORDERID="select orderid from orderdetails where cid = ?";
	public static final String ADD_ORDER_DETAILS = "INSERT INTO orderdetails values(sequence_oid.NEXTVAL,sequence_cid.CURRVAL,SYSDATE,?)";
	public static final String CHECK_VALID_ID = "SELECT * FROM orderdetails WHERE orderid=?";
	//"Select purchaseid_sequence.CURRVAL FROM DUAL";
}
