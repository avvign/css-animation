function validate(){
	var flag=false;
	var userName=f1.userName.value
	var userpasswd=f1.userPwd.value
	/*if(userName==""||userName==null){
		document.getElementById('userErrMsg').innerHTML="*Please enter a Name"
			flag=false;
	} else if(userpasswd==""||userpasswd==null){
		document.getElementById('pwdErrMsg').innerHTML="*Please enter a Password"
			document.getElementById('userErrMsg').innerHTML=""
			flag=false;
	} else {
		flag=true;
	}*/
	
	if(username!=tom && userpasswd!=tom123){
		document.getElementById('innerhtml').innerHTML="*Please enter a Name"
			flag=false;
	} else if(userpasswd==""||userpasswd==null){
		document.getElementById('innerhtml').innerHTML="*Please enter a Password"
			document.getElementById('userErrMsg').innerHTML=""
			flag=false;
	} else if(username==""||username==null){
		document.getElementById('innerhtml').innerHTML="*Please enter a Name"
			flag=false;
		
	} else {
		flag=true;
	}
	
	return flag;
}