package com.capgemini.pizza.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.pizza.exception.PizzaException;
import com.capgemini.pizza.util.DBConnection;

public class CustomerDAOImpl implements ICustomerDAO{

	@Override
	public Long addCustomerDetails(String customerName,
			String address, Long phoneNumber,Double totalPrice,Integer quantity) throws PizzaException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.ADD_CUSTOMER_DETAILS);
				Statement statement = connection.createStatement();
				){
			preparedStatement.setString(1, customerName);
			preparedStatement.setLong(2,phoneNumber);
			preparedStatement.setString(3, address);
			//System.out.println("in try");
			int n=preparedStatement.executeUpdate();
			//System.out.println(n);
			if(n>0){
				//System.out.println("n"+n);
				ResultSet resultSet = statement.executeQuery(QueryMapper.CUSTOMER_ID);
				//System.out.println("after rs");
				if(resultSet.next()){
					Long customerId = resultSet.getLong(1);
					//Long orderid = new OrderDetailsDAOImpl().placeOrder(customerId,totalPrice);
					return customerId ;
				}
			}
		}catch(SQLException e){
			
		}
		return null;
	}
	
}
