package com.capgemini.pizza.service;

import java.util.List;

import com.capgemini.pizza.bean.Pizza;
import com.capgemini.pizza.bean.PizzaOrder;
import com.capgemini.pizza.exception.PizzaException;

public interface IOrderDetailsService {
	public abstract PizzaOrder getOrderDetails(Long orderId)throws PizzaException;

	public abstract Long placeOrder(Long customerId, Double totalPrice,Integer quantity) throws PizzaException;
	public abstract boolean isValidOrderId(Long orderId)throws PizzaException;

	public abstract List<Pizza> getPizzaDetails() throws PizzaException;
}
