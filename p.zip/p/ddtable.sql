create table demand_draft(transactionid number,cusomername varchar2(20),infavourof varchar2(20),
mobile varchar2(10),demanddraftdate date,amount number,commission number,
description varchar2(20));

create sequence transaction_id;