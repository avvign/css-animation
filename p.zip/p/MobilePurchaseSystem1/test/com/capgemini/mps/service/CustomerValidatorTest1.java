package com.capgemini.mps.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class CustomerValidatorTest1 {

	@Test
	public void testIsValidCustomerName() {
		assertTrue(new CustomerValidator().isValidCustomerName("Ravi Kumar"));
	}

	@Test
	public void testIsNotValidCustomerName() {
		assertFalse(new CustomerValidator().isValidCustomerName("Ravi Kumar XXXXXXXXXX"));
	}

	@Test
	public void testIsValidEmail() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsValidPhoneNumber() {
		fail("Not yet implemented");
	}

}
