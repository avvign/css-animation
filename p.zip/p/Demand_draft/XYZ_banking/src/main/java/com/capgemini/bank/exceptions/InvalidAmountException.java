package com.capgemini.bank.exceptions;

public class InvalidAmountException extends Exception {
	
	
	//create a user defined exception
	public InvalidAmountException(String message)	{
		super(message);
	}

}
