package com.capgemini.pizza.service;

import java.sql.SQLException;


import java.util.List;

import com.capgemini.pizza.bean.Pizza;
import com.capgemini.pizza.bean.PizzaOrder;
import com.capgemini.pizza.dao.IOrderDetailsDAO;
import com.capgemini.pizza.dao.OrderDetailsDAOImpl;
import com.capgemini.pizza.exception.PizzaException;

public class OrderDetailsServiceImpl implements IOrderDetailsService {
	private IOrderDetailsDAO orderDAO=new OrderDetailsDAOImpl();
	
	public PizzaOrder getOrderDetails(Long orderId) throws PizzaException {
		PizzaOrder order = orderDAO.getOrderDetails(orderId);
		return order;
	}
	@Override
	public Long placeOrder(Long customerId, Double totalPrice,Integer quantity,String name)
			throws PizzaException {
		try {
			Long orderId =orderDAO.placeOrder(customerId, totalPrice);
			System.out.println(name);
			orderDAO.updateQuantity(name,quantity);
			return orderId;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
	}
	}
	
	@Override
	public boolean isValidOrderId(Long orderId) throws PizzaException {
		return orderDAO.isValidOrderId(orderId);
		
	
}
	@Override
	public List<Pizza> getPizzaDetails() throws PizzaException {
		List<Pizza> pizzaDetails=  orderDAO.getPizzaDetails();
		return pizzaDetails;
	
		
	}
}
