package com.capgemini.pizza.dao;

public interface QueryMapper {
	
	public static final String VIEW_ALL_PIZZAS="SELECT * FROM pizza";
	public static final String ORDER_ID="SELECT sequence_oid.CURRVAL from dual";
	public static final String DISPLAY_ORDER="SELECT * FROM orderdetails where orderid=?";
	public static final String ADD_CUSTOMER_DETAILS="INSERT INTO customer2 VALUES(sequence_cid.NEXTVAL,?,?,?)";
	public static final String CUSTOMER_ID="SELECT sequence_cid.CURRVAL from dual";
	public static final String ADD_ORDER_DETAILS="INSERT into orderdetails values(sequence_oid.NEXTVAL,?,SYSDATE,?)";
	public static final String PIZZA_QUANTITY_UPDATE="UPDATE pizza set quantity=quantity-? where p_nmae=?";
	//public static final String INSERT_CUSID="INSERT INTO orderdetails(cid) VALUES";
	public static final String CHECK_VALID_ORDERID="SELECT * from orderdetails WHERE orderid=? ";
}
