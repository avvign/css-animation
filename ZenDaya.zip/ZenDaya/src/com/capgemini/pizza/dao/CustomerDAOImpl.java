package com.capgemini.pizza.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.pizza.exception.PizzaException;
import com.capgemini.pizza.util.DBConnection;

public class CustomerDAOImpl implements ICustomerDAO{

	@Override
	public Long addCustomerDetails(String customerName,
			String address, Long phoneNumber,Double totalPrice,Integer quantity) throws PizzaException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.ADD_CUSTOMER_DETAILS);
				Statement statement = connection.createStatement();
				){
			preparedStatement.setString(1, customerName);
			preparedStatement.setLong(2,phoneNumber);
			preparedStatement.setString(3, address);
			
			int n=preparedStatement.executeUpdate();
			
			if(n>0){
				
				ResultSet resultSet = statement.executeQuery(QueryMapper.CUSTOMER_ID);
				
				if(resultSet.next()){
					Long customerId = resultSet.getLong(1);
					
					return customerId ;
				}
			}
		}catch(SQLException e){
			
		}
		return null;
	}
	
}
