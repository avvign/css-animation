package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO{
	final static Logger logger=Logger.getLogger(DemandDraftDAO.class);

	//make calls to  db
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		
		int count=0;
		//parameterized sql statement
		String sql="insert into demand_draft values(null,?,?,?,?,?,?,?)";
		
		try(Connection connection=getConnection()) {
				//fetch details from the demandDraft object
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setString(1, demandDraft.getCustomerName());
				statement.setString(2, demandDraft.getInFavourOf());
				statement.setString(3, demandDraft.getMobile());
				statement.setDate(4, java.sql.Date.valueOf(demandDraft.getDate()));
				statement.setDouble(5,demandDraft.getAmount());
				statement.setInt(6, demandDraft.getCommission());		
				statement.setString(7, demandDraft.getDescription());
				
				count=statement.executeUpdate();
				if(count>0) //on successful insertion, give the transaction ID
					return TransactionID();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		return 0;
		
		
		
		
	}

public int TransactionID() {
		
		String sql="select max(transaction_id) from demand_draft"; //Statement to fetch the last transaction_id from the sequence
		try(Connection conn=getConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet resultSet= pst.executeQuery();
			while(resultSet.next()) {
				
				return resultSet.getInt(1); //fetch the transaction_id from the selected row
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return 0;
		
	}
	@Override
	
	//fetch the entire row
	public DemandDraft getDemandDraftDetails(int transactionId) {

		DemandDraft demandDraft=new DemandDraft();
		
		String sql="select * from demand_draft where transaction_id = ?"; //parameterized sql statement where transaction id is fed by the user
		try(Connection conn=getConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, transactionId);
			ResultSet resultSet= pst.executeQuery();
			while(resultSet.next()) {    //get details from the selected row
				
				demandDraft.setCustomerName(resultSet.getString(1));
				demandDraft.setInFavourOf(resultSet.getString(2));
				demandDraft.setMobile(resultSet.getString(3));
				demandDraft.setDate(resultSet.getDate(4).toLocalDate());
				demandDraft.setAmount(resultSet.getInt(5));
				demandDraft.setCommission(resultSet.getInt(6));
				demandDraft.setDescription(resultSet.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return demandDraft;
	
	}
	
	
	
	//Creating connection to MySQL
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");//register driver
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/xyzbank", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			logger.error("Connection Error!");
			e.printStackTrace();
		}
		return connection;
	}

}
