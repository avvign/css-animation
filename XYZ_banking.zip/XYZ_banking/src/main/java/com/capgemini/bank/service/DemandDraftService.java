package com.capgemini.bank.service;

import org.apache.log4j.Logger;


import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exceptions.InvalidAmountException;

public class DemandDraftService implements IDemandDraftService {
	
	final static Logger logger=Logger.getLogger(DemandDraftService.class);
	IDemandDraftDAO demandDraftDAO=new DemandDraftDAO();

	//check for any exceptions and send request to DAO layer
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft){
		if(demandDraft==null) {
			logger.error("Invalid argument exception");
			throw new IllegalArgumentException();
		}
		
		else if(demandDraft.getAmount()<=0)
		{
			logger.error("Invalid amount!!!");
			try {
				throw new InvalidAmountException("Invalid Amount!");
			} catch (InvalidAmountException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		demandDraftDAO.addDemandDraftDetails(demandDraft);
		
		return 0;
	}

	//route the getdetails request to DAO layer
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		
		return demandDraftDAO.getDemandDraftDetails(transactionId);
	}

}
