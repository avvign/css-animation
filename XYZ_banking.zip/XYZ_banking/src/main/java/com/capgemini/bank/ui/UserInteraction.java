package com.capgemini.bank.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.Utility;

public class UserInteraction {
	Scanner scanner=new Scanner(System.in);
	
	//prompt details from customer;
	public DemandDraft getDetails() {
		DemandDraft demandDraft=new DemandDraft();
		demandDraft.setCustomerName(promptName());
		demandDraft.setMobile(promptMobile());
		demandDraft.setInFavourOf(promptInFavourOf());
		demandDraft.setAmount(promptAmount());
		demandDraft.setDescription(promptDescription());
		demandDraft.setDate(LocalDate.now());
		demandDraft.setCommission(calculateCommission(demandDraft.getAmount()));
		
		return demandDraft;
	}
	
	//ask for customer name
	public String promptName(){
	
		boolean flag=false;
		String name;
		do {
		System.out.println("Enter the name of the customer : ");
		name=scanner.next();
		flag=Utility.isValidName(name);
		if(!flag)
			System.out.println("invalid name!");
		}while(!flag);
		
		return name;
		
	}
	
	//ask for mobile no
	public String promptMobile() {
		boolean flag=false;
		String mobile;
		do {
		System.out.println("Enter the customer phone number : ");
		mobile=scanner.next();
		flag=Utility.isValidMobile(mobile);
		if(!flag)
			System.out.println("invalid number!");
		}while(!flag);
		
		return mobile;
		
		
	}
	
	//ask the recipient;
	public String promptInFavourOf() {
		boolean flag=false;
		String inFavourOf;
		do {
		System.out.println("In favour of : ");
		inFavourOf=scanner.next();
		flag=Utility.isValidInFavourOf(inFavourOf);
		if(!flag)
			System.out.println("invalid in favour of!");
		}while(!flag);
		
		return inFavourOf;
		
	}
	
	//ask for dd amount
	public double promptAmount() {
			
		System.out.println("Enter demand draft amount(in Rs.) : ");
		return scanner.nextDouble();
	}
	
	public String promptDescription() {
		System.out.println("Enter remarks");
		return scanner.next();
	}
	
	public int calculateCommission(double amount) {
		if(amount<=5000)
			return 10;
		else if(amount<=10000)
			return 41;
		else if(amount<=100000)
			return 51;
		else if(amount<=500000)
			return 306;
		else return 0;
	}
	

}
